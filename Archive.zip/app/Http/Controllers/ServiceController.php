<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Service;


class ServiceController extends Controller
{
    public function service(Service $slug)
    {
        $services = Service::all();

        return view('Services.service', compact('slug','services'));
    }
}
