<?php $__env->startSection('content'); ?>
<div class="service">
    <div class="row justify-content-center">
        <div class="col-md-12 service-banner" style="background-image: url('<?php echo e(url("/storage/{$slug->thumbnail}")); ?>'); background-repeat: no-repeat; background-size: cover;">

            <nav class="navbar navbar-expand-md navbar-light shadow-sm">
                <div class="container">
                    <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
                        <?php echo e(config('app.name', 'Laravel')); ?>

                    </a>
                    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="<?php echo e(__('Toggle navigation')); ?>">
                        <span class="navbar-toggler-icon"></span>
                    </button>

                    <div class="collapse navbar-collapse" id="navbarSupportedContent">
                        <!-- Left Side Of Navbar -->
                        <ul class="navbar-nav mx-auto">
                        <li class="nav-item">
                            <a class="nav-link text-white" href="#">Home</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-white" href="/about">About</a>
                        </li>
                        <li class="dropdown nav-item">
                            <a class= "dropdown-toggle nav-link text-white" href="#" style="text-decoration:none;" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            Services
                            </a>
                            <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
                                <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <a class="dropdown-item text-white" href="/services/<?php echo e($service->slug); ?>"><?php echo e($service->title); ?></a>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>                           
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-white" href="#section-projects">Projects</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-white" href="#section-prices">Packages</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-white" href="/contact">Contact</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-white" href="/blogs">Blog</a>
                        </li>
                    </ul>

                        <!-- Right Side Of Navbar -->
                        <ul class="navbar-nav ms-auto">
                            <!-- Authentication Links -->
                            <?php if(auth()->guard()->guest()): ?>
                                <?php if(Route::has('login')): ?>
                                    <li class="nav-item">
                                        <a class="nav-link" href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a>
                                    </li>
                                <?php endif; ?>

                                <?php if(Route::has('register')): ?>
                                    <li class="nav-item">
                                        <a class="nav-link" href="<?php echo e(route('register')); ?>"><?php echo e(__('Register')); ?></a>
                                    </li>
                                <?php endif; ?>
                            <?php else: ?>
                                <li class="nav-item dropdown">
                                    <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                        <?php echo e(Auth::user()->name); ?>

                                    </a>

                                    <div class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                                        <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                        onclick="event.preventDefault();
                                                        document.getElementById('logout-form').submit();">
                                            <?php echo e(__('Logout')); ?>

                                        </a>

                                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                            <?php echo csrf_field(); ?>
                                        </form>
                                    </div>
                                </li>
                            <?php endif; ?>
                        </ul>
                    </div>
                </div>
            </nav>

            <div class="row">
                <div class="col-md-12 header" style="">
                    <h1 class="text-center"><?php echo e($slug->title); ?></h1>
                    <h4 class="text-center">home >> services >> <?php echo e($slug->title); ?></h1>

                </div>
            </div>
        </div>
        <div class="container" style="width:70%;margin:auto;">
            <div class="row section-service" style="align-items:flex-start;justify-content:flex-start;">
                <div class="col-lg-3 col-md-12 d-flex justify-content-center align-items-center author" style="flex-direction:column; margin-top:100px;">
                    <img src="/storage/author.png" class="roounded-circle" height="260px" width="260px">
                    <h5 class="text-center">OlePundit</h5>
                    <h6 class="text-center"><?php echo e($slug->created_at); ?></h6>

                </div>
                <div class="col-lg-9 col-md-12 body">
                    <?php echo e($slug->body); ?>

                    <div class="row">
                        <button>Request Quotation</button>

                    </div>
                </div>
            </div>
        </div>
        <div class="row section-more">
            <h2 class="text-center">Read <span>More</span></h2>
            <div class="custom-card">
                <img src="/storage/more.png" class="card-img-top">
                <div class="card-body">
                    <h4>GRAPHIC DESIGN IN KENYA</h4>
                    <p>Lorem Ipsum has been the industry's 
                    standard dummy text ever since the 1500s
                    ....</p>
                    <button>Read more</button>
                </div>
            </div>
            <div class="custom-card">
                <img src="/storage/more.png" class="card-img-top">
                <div class="card-body">
                    <h4>GRAPHIC DESIGN IN KENYA</h4>
                    <p>Lorem Ipsum has been the industry's 
                    standard dummy text ever since the 1500s
                    ....</p>
                    <button>Read more</button>
                </div>
            </div>
            <div class="custom-card">
                <img src="/storage/more.png" class="card-img-top">
                <div class="card-body">
                    <h4>GRAPHIC DESIGN IN KENYA</h4>
                    <p>Lorem Ipsum has been the industry's 
                    standard dummy text ever since the 1500s
                    ....</p>
                    <button>Read more</button>
                </div>
            </div>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/imac/Documents/nex-l/nexl/resources/views/Services/service.blade.php ENDPATH**/ ?>